Open q9_json_to_table.html in a browser.
