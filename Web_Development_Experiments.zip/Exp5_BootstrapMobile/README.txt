Open q5_bootstrap_mobile.html (requires internet for CDN).
