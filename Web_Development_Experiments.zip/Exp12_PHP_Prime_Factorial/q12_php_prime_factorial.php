<?php
// q12_php_prime_factorial.php
$res = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    if ($action === 'prime') {
        $n = trim($_POST['pnum'] ?? '');
        if (!preg_match('/^\d+$/', $n)) $res = "Enter non-negative integer.";
        else {
            $n = intval($n);
            if ($n < 2) $is = false;
            else {
                $is = true;
                for ($i=2;$i<=intval(sqrt($n));$i++){
                    if ($n % $i === 0){ $is = false; break; }
                }
            }
            $res = $n . ($is ? " is Prime." : " is not Prime.");
        }
    } elseif ($action === 'fact') {
        $n = trim($_POST['fnum'] ?? '');
        if (!preg_match('/^\d+$/', $n)) $res = "Enter non-negative integer.";
        else {
            $n = intval($n);
            $fact = 1;
            for ($i=2;$i<= $n; $i++) $fact *= $i;
            $res = "Factorial of {$n} is {$fact}.";
        }
    }
}
?>
<!doctype html><html><head><meta charset="utf-8"><title>Prime & Factorial</title></head><body>
  <h3>Prime Check</h3>
  <form method="post">
    <input type="hidden" name="action" value="prime">
    <input type="text" name="pnum" placeholder="Enter integer">
    <button type="submit">Check Prime</button>
  </form>

  <h3>Factorial</h3>
  <form method="post">
    <input type="hidden" name="action" value="fact">
    <input type="text" name="fnum" placeholder="Enter integer">
    <button type="submit">Get Factorial</button>
  </form>

  <div style="margin-top:10px;color:green;"><?php echo htmlspecialchars($res); ?></div>
</body></html>
