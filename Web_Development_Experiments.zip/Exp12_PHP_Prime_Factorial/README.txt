Place in XAMPP htdocs or run with php -S localhost:8000
