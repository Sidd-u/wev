<?php
// q10_php_digits_palindrome.php
// Run with PHP built-in server: php -S localhost:8000
$result = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    if ($action === 'sumdigits') {
        $num = $_POST['num'] ?? '';
        $num = trim($num);
        if (!preg_match('/^-?\d+$/', $num)) {
            $result = "Enter a valid integer.";
        } else {
            $n = ltrim($num, '-');
            $sum = 0;
            for ($i=0;$i<strlen($n);$i++) $sum += intval($n[$i]);
            $result = "Sum of digits of {$num} is {$sum}.";
        }
    } elseif ($action === 'palindrome') {
        $num = $_POST['pnum'] ?? '';
        $num = trim($num);
        if (!preg_match('/^-?\d+$/', $num)) {
            $result = "Enter a valid integer.";
        } else {
            $n = ltrim($num,'-');
            $rev = strrev($n);
            $is = ($n === $rev) ? 'is' : 'is not';
            $result = "{$num} {$is} a palindrome (ignoring sign).";
        }
    }
}
?>
<!doctype html>
<html><head><meta charset="utf-8"><title>Digits & Palindrome</title></head><body>
  <h3>Sum of Individual Digits</h3>
  <form method="post">
    <input type="hidden" name="action" value="sumdigits">
    <input type="text" name="num" placeholder="Enter integer">
    <button type="submit">Compute</button>
  </form>

  <h3>Palindrome Check</h3>
  <form method="post">
    <input type="hidden" name="action" value="palindrome">
    <input type="text" name="pnum" placeholder="Enter integer">
    <button type="submit">Check</button>
  </form>

  <div style="margin-top:12px;color:green;"><?php echo htmlspecialchars($result); ?></div>
</body></html>
