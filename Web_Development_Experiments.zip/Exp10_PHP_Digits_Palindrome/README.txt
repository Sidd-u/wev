Place this file in XAMPP htdocs and open via browser. Or run: php -S localhost:8000
