Open q3_calculator.html in a browser.
