Open q4_login_validation.html in a browser.
