from flask import Flask, g, render_template, request, jsonify, session, redirect, url_for
import sqlite3, os, random, re

app = Flask(__name__)
app.secret_key = 'change_this_secret'
DB = os.path.join(os.path.dirname(__file__), 'q17_test.db')

def get_db():
    db = getattr(g, '_db', None)
    if db is None:
        need_create = not os.path.exists(DB)
        db = g._db = sqlite3.connect(DB)
        db.row_factory = sqlite3.Row
        if need_create:
            cur = db.cursor()
            cur.execute('CREATE TABLE std (sid INTEGER PRIMARY KEY AUTOINCREMENT, sname TEXT, uname TEXT, pwd TEXT)')
            cur.execute('CREATE TABLE que (qid INTEGER PRIMARY KEY AUTOINCREMENT, que TEXT, opt1 TEXT, opt2 TEXT, opt3 TEXT, opt4 TEXT, ans TEXT)')
            cur.execute('CREATE TABLE results (rid INTEGER PRIMARY KEY AUTOINCREMENT, sid INTEGER, score INTEGER, created DATETIME DEFAULT CURRENT_TIMESTAMP)')
            cur.execute('INSERT INTO std (sname, uname, pwd) VALUES (?,?,?)', ('Asha','asha','Pass@123'))
            sample = [
                ("Capital of India?","Mumbai","New Delhi","Kolkata","Chennai","New Delhi"),
                ("2+3=?","3","4","5","6","5"),
                ("Largest planet?","Earth","Mars","Jupiter","Saturn","Jupiter")
            ]
            for s in sample:
                cur.execute('INSERT INTO que (que,opt1,opt2,opt3,opt4,ans) VALUES (?,?,?,?,?,?)', s)
            db.commit()
    return db

@app.teardown_appcontext
def close_db(exc):
    db = getattr(g, '_db', None)
    if db is not None: db.close()

@app.route('/')
def index():
    if 'sid' in session:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))

@app.route('/login')
def login():
    return render_template('q17_login.html')

@app.route('/api/login', methods=['POST'])
def api_login():
    data = request.get_json() or {}
    uname = (data.get('uname') or '').strip(); pwd = data.get('pwd') or ''
    if not re.match(r'^[A-Za-z0-9_]{3,20}$', uname): return jsonify({'ok':False,'msg':'Invalid username'})
    db = get_db()
    r = db.execute('SELECT sid,sname FROM std WHERE uname=? AND pwd=?', (uname,pwd)).fetchone()
    if r:
        session['sid'] = r['sid']; session['sname'] = r['sname']; return jsonify({'ok':True})
    return jsonify({'ok':False,'msg':'Invalid credentials'})

@app.route('/dashboard')
def dashboard():
    if 'sid' not in session: return redirect(url_for('login'))
    return render_template('q17_dashboard.html', sname=session.get('sname'))

@app.route('/start_test')
def start_test():
    if 'sid' not in session: return redirect(url_for('login'))
    db = get_db()
    rows = db.execute('SELECT * FROM que').fetchall()
    qs = [dict(r) for r in rows]
    random.shuffle(qs)
    for q in qs:
        q.pop('ans', None)
    return render_template('q17_test.html', questions=qs)

@app.route('/submit_test', methods=['POST'])
def submit_test():
    if 'sid' not in session: return jsonify({'ok':False,'msg':'Not logged in'})
    data = request.get_json() or {}
    answers = data.get('answers', {})
    db = get_db()
    score = 0
    for qid_str, sel in answers.items():
        try:
            qid = int(qid_str)
        except:
            continue
        row = db.execute('SELECT ans FROM que WHERE qid=?', (qid,)).fetchone()
        if row and row['ans'] == sel:
            score += 1
    db.execute('INSERT INTO results (sid, score) VALUES (?,?)', (session['sid'], score))
    db.commit()
    return jsonify({'ok':True, 'score':score})

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True)
