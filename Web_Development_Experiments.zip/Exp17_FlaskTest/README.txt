Install Flask (pip install Flask). Run: python q17_flask_test.py
Default user: uname=asha pwd=Pass@123
