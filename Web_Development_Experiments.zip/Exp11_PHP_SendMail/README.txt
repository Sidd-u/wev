Install PHPMailer via Composer: composer require phpmailer/phpmailer
Place vendor/ next to this file. Update SMTP credentials.
