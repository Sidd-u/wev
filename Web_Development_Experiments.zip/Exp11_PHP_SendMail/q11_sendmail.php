<?php
// q11_sendmail.php
// Requires composer autoload and phpmailer installed
// Usage: php -S localhost:8000

require 'vendor/autoload.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$info = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $to = trim($_POST['recipient'] ?? '');
    $sub = trim($_POST['subject'] ?? '');
    $msg = trim($_POST['message'] ?? '');

    if (!filter_var($to, FILTER_VALIDATE_EMAIL)) {
        $info = "Enter a valid recipient email.";
    } else {
        $mail = new PHPMailer(true);
        try {
            // SMTP settings - Gmail example (you may need App Password or OAuth)
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'yourgmail@gmail.com';   // CHANGE
            $mail->Password = 'your_app_password';     // CHANGE (App password recommended)
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
            $mail->Port = 465;

            $mail->setFrom('yourgmail@gmail.com', 'Sender Name'); // CHANGE
            $mail->addAddress($to);
            $mail->isHTML(true);
            $mail->Subject = $sub;
            $mail->Body = nl2br(htmlspecialchars($msg));
            $mail->send();
            $info = "Email sent to {$to}";
        } catch (Exception $e) {
            $info = "Mail error: " . $mail->ErrorInfo;
        }
    }
}
?>
<!doctype html>
<html><head><meta charset="utf-8"><title>Send Mail</title></head><body>
<h3>Send Email (PHPMailer + SMTP)</h3>
<form method="post">
  <label>Recipient: <input type="email" name="recipient" required></label><br>
  <label>Subject: <input type="text" name="subject"></label><br>
  <label>Message: <br><textarea name="message" rows="6" cols="50"></textarea></label><br>
  <button type="submit">Send</button>
</form>
<div style="margin-top:10px;color:green;"><?php echo htmlspecialchars($info); ?></div>
<p><strong>Notes:</strong> For Gmail SMTP, use an App Password (or OAuth2). Replace username/password above. Composer and PHPMailer required.</p>
</body></html>
