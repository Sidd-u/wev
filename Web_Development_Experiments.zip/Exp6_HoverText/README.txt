Open q6_hover_text.html in a browser.
