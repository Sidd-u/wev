Place in XAMPP htdocs. Ensure uploads/ is writable. Run via browser.
