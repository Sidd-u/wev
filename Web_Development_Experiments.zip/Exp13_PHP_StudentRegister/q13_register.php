<?php
// q13_register.php
// Run: php -S localhost:8000
$dbfile = __DIR__ . '/q13_students.sqlite';
$created = !file_exists($dbfile);
$db = new PDO('sqlite:' . $dbfile);
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

if ($created) {
    $db->exec("CREATE TABLE students (sid INTEGER PRIMARY KEY AUTOINCREMENT, sname TEXT, age INTEGER, course TEXT, photo TEXT)");
}

$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $sname = trim($_POST['sname'] ?? '');
    $age = intval($_POST['age'] ?? 0);
    $course = trim($_POST['course'] ?? '');
    $photoPath = '';

    if (!is_dir(__DIR__ . '/uploads')) mkdir(__DIR__ . '/uploads', 0755, true);

    if (!empty($_FILES['photo']['tmp_name'])) {
        $ext = pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION);
        $filename = 'p_' . time() . '_' . rand(1000,9999) . '.' . $ext;
        $dest = __DIR__ . '/uploads/' . $filename;
        if (move_uploaded_file($_FILES['photo']['tmp_name'], $dest)) {
            $photoPath = 'uploads/' . $filename;
        }
    }

    $stmt = $db->prepare("INSERT INTO students (sname, age, course, photo) VALUES (?, ?, ?, ?)");
    $stmt->execute([$sname, $age, $course, $photoPath]);
    $msg = "Student registered.";
}

$rows = $db->query("SELECT * FROM students ORDER BY sid DESC")->fetchAll(PDO::FETCH_ASSOC);
?>
<!doctype html><html><head><meta charset="utf-8"><title>Student Registration</title></head><body>
<h3>Register Student</h3>
<form method="post" enctype="multipart/form-data">
  <label>Name: <input type="text" name="sname" required></label><br>
  <label>Age: <input type="number" name="age" required></label><br>
  <label>Course: <input type="text" name="course" required></label><br>
  <label>Photo: <input type="file" name="photo" accept="image/*"></label><br>
  <button type="submit">Register</button>
</form>

<div style="color:green"><?php echo htmlspecialchars($msg); ?></div>

<h3>Registered Students</h3>
<table border="1" cellpadding="6">
  <tr><th>Sid</th><th>Sname</th><th>Age</th><th>Course</th><th>Photo</th></tr>
  <?php foreach($rows as $r): ?>
    <tr>
      <td><?php echo $r['sid']; ?></td>
      <td><?php echo htmlspecialchars($r['sname']); ?></td>
      <td><?php echo $r['age']; ?></td>
      <td><?php echo htmlspecialchars($r['course']); ?></td>
      <td><?php if ($r['photo']) echo '<img src="'.htmlspecialchars($r['photo']).'" width="80">'; ?></td>
    </tr>
  <?php endforeach; ?>
</table>
</body></html>
