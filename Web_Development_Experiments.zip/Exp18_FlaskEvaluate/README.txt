Install Flask (pip install Flask). Run: python q18_flask_eval.py
Default user: uname=asha pwd=Pass@123
