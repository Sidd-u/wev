from flask import Flask, g, render_template, request, jsonify, session, redirect, url_for
import sqlite3, os, re

app = Flask(__name__)
app.secret_key = 'change_this_secret'
DB = os.path.join(os.path.dirname(__file__), 'q16_students.db')

def get_db():
    db = getattr(g, '_db', None)
    if db is None:
        need_create = not os.path.exists(DB)
        db = g._db = sqlite3.connect(DB)
        db.row_factory = sqlite3.Row
        if need_create:
            cur = db.cursor()
            cur.execute('CREATE TABLE std (sid INTEGER PRIMARY KEY AUTOINCREMENT, sname TEXT, uname TEXT, pwd TEXT)')
            cur.execute('INSERT INTO std (sname, uname, pwd) VALUES (?,?,?)', ('Asha','asha','Pass@123'))
            db.commit()
    return db

@app.teardown_appcontext
def close_db(exc):
    db = getattr(g, '_db', None)
    if db is not None:
        db.close()

@app.route('/')
def index():
    if 'sid' in session:
        return redirect(url_for('dashboard'))
    return render_template('login.html')

@app.route('/api/login', methods=['POST'])
def api_login():
    data = request.get_json() or {}
    uname = (data.get('uname') or '').strip()
    pwd = data.get('pwd') or ''
    if not re.match(r'^[A-Za-z0-9_]{3,20}$', uname):
        return jsonify({'ok': False, 'msg': 'Invalid username format'})
    if not re.match(r'^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{6,}$', pwd):
        return jsonify({'ok': False, 'msg': 'Invalid password format'})

    db = get_db()
    cur = db.execute('SELECT sid, sname FROM std WHERE uname=? AND pwd=?', (uname, pwd))
    row = cur.fetchone()
    if row:
        session['sid'] = row['sid']
        session['sname'] = row['sname']
        return jsonify({'ok': True, 'msg': 'Logged in'})
    return jsonify({'ok': False, 'msg': 'Invalid credentials'})

@app.route('/dashboard')
def dashboard():
    if 'sid' not in session:
        return redirect(url_for('index'))
    return render_template('dashboard.html', sname=session.get('sname'))

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
