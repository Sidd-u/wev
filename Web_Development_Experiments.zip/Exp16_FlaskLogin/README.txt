Install Flask (pip install Flask). Run: python q16_flask_app.py
Default user: uname=asha pwd=Pass@123
