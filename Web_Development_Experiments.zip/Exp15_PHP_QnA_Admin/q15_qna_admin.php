<?php
// q15_qna_admin.php
// Run: php -S localhost:8000
$dbf = __DIR__ . '/q15_qna.sqlite';
$created = !file_exists($dbf);
$db = new PDO('sqlite:' . $dbf);
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
if ($created) {
    $db->exec("CREATE TABLE qna (id INTEGER PRIMARY KEY AUTOINCREMENT, que TEXT, ans TEXT)");
}

$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add'])) {
    $que = trim($_POST['que'] ?? '');
    $ans = trim($_POST['ans'] ?? '');
    if ($que === '') $msg = "Question required.";
    else {
        $st = $db->prepare("INSERT INTO qna (que, ans) VALUES (?, ?)");
        $st->execute([$que, $ans]);
        $msg = "Inserted.";
    }
}

$qrows = $db->query("SELECT * FROM qna ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);
?>
<!doctype html><html><head><meta charset="utf-8"><title>QnA Admin</title></head><body>
  <h3>Admin: Insert Question & Answer</h3>
  <form method="post">
    <textarea name="que" rows="3" cols="60" placeholder="Question"></textarea><br>
    <textarea name="ans" rows="3" cols="60" placeholder="Answer (optional)"></textarea><br>
    <button type="submit" name="add">Add Q&A</button>
  </form>
  <div style="color:green"><?php echo htmlspecialchars($msg); ?></div>

  <h3>All Questions</h3>
  <ul>
    <?php foreach($qrows as $r): ?>
      <li><strong><?php echo htmlspecialchars($r['que']); ?></strong><br>
          <?php echo nl2br(htmlspecialchars($r['ans'])); ?></li>
    <?php endforeach; ?>
  </ul>
</body></html>
