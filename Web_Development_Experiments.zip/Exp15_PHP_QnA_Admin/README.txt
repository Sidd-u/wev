Place in XAMPP htdocs. Open in browser to add/view Q&A.
