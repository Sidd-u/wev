<?php
// q14_cookie_users.php
// Run php -S localhost:8000
$msg = '';
$users = ['user1'=>'pwd1','user2'=>'pwd2','user3'=>'pwd3','user4'=>'pwd4'];

if (!isset($_COOKIE['users_q14'])) {
    setcookie('users_q14', json_encode($users), time()+3600*24, "/");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $uid = $_POST['uid'] ?? '';
    $pwd = $_POST['pwd'] ?? '';
    $cookie = $_COOKIE['users_q14'] ?? '';
    if ($cookie) {
        $arr = json_decode($cookie, true);
        if (isset($arr[$uid]) && $arr[$uid] === $pwd) {
            $msg = "Login success for {$uid}.";
        } else {
            $msg = "Invalid credentials.";
        }
    } else {
        $msg = "User cookie not set.";
    }
}
?>
<!doctype html><html><head><meta charset="utf-8"><title>Cookie Login</title></head><body>
  <h3>Login (reads credentials from cookie)</h3>
  <form method="post">
    <input name="uid" placeholder="userid"><br>
    <input name="pwd" placeholder="password" type="password"><br>
    <button type="submit">Login</button>
  </form>
  <div style="margin-top:10px;color:green;"><?php echo htmlspecialchars($msg); ?></div>
  <p>Note: default users are user1..user4 with pwd1..pwd4 stored in cookie for 24 hours.</p>
</body></html>
