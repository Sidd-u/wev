Place in XAMPP htdocs. Open in browser. Note: insecure demo only.
