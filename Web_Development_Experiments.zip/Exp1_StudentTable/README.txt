Open q1_students.html in a browser.
