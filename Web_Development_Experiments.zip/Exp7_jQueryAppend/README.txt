Open q7_jquery_append.html (internet required for jQuery CDN).
