Open q8_jquery_alert.html (internet required for jQuery CDN).
