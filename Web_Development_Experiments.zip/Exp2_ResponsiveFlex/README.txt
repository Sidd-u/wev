Open q2_flexpage.html in a browser and resize to test breakpoints.
